export const PORT = process.env.PORT || 8000;

export const mongoURL ="mongodb://127.0.0.1:27017/LostandFound";    